<!DOCTYPE html>
<html>
<head>
    <title>Fusion Artists</title>
    <link href="TArtists.css" rel="stylesheet" />
</head>
<body>
    <?php
    $document_root = $_SERVER['DOCUMENT_ROOT'];
    $favArtist = $_POST["favArtist"];

    $fp = fopen($document_root."/My Website/FavArtList.txt", 'ab');
    fwrite($fp, "\n".$favArtist);
    fclose($fp);

    $fp = fopen($document_root."/My Website/FavArtList.txt", 'rb');

    rewind($fp);

    while (!feof($fp)) {
        $list= fgets($fp);
        echo htmlspecialchars($list)."<br />";
    }
    fclose($fp);
    ?>
</body>
</html>