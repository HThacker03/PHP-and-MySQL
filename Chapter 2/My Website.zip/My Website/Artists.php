<!DOCTYPE html>
<html>
<head>
    <title>Fusion Artists</title>
    <link href="TArtists.css" rel="stylesheet" />
</head>
<body>
    <h1>Top Artists in the genre:</h1>
    <?php
    $genre1 = $_POST["genre1"];
    $genre2 = $_POST["genre2"];

    $popPunk = "<p>Fall Out Boy </br>All Time Low </br>blink-182 </br>The Offspring</p>";
    $popRock = "<p>Fleetwood Mac </br>Elton John </br>The Beatles </br>Prince</p>";
    $popHiphop = "<p>Nicki Minaj </br> will.i.am </br>Macklemore </br>the Black Eyed Peas</p>";
    $popCountry = "<p>Taylor Swift </br>Shania Twain </br>Luke Bryan </br>Jessica Simpson</p>";
    $punkRock = "<p>Green Day </br>Ramones </br>The Clash </br>Misfits</p>";
    $rockHiphop = "<p>Beastie Boys </br>Limp Bizkit </br>Gorillaz </br>Insane Clown Posse</p>";
    $rockCountry = "<p>Alabama </br>The Chicks </br>Eagles </br>The Grateful Dead</p>";
    $punkHiphop = "<p>Nothing,Nowhere </br>Travis Scott </br>Public Enemy </br>6ix9ine</p>";
    $punkCountry = "<p>Social Distortion </br>The Gun Club </br>The Long Ryders </br>The Beat Farmers</p>";
    $countryHiphop = "<p>Jelly Roll </br>Beyonce </br>Lil Nas X </br>Gutter Souls</p>";

    echo "<h2>".$genre1." ".$genre2."</h2>";
    
    if (($genre1 == "Pop" && $genre2 == "Rock") || ($genre2 == "Pop" && $genre1 == "Rock")) {
        echo $popRock;
    }
    else if (($genre1 == "Pop" && $genre2 == "Punk") || ($genre2 == "Pop" && $genre1 == "Punk")) {
        echo $popPunk;
    }
    else if (($genre1 == "Pop" && $genre2 == "Hip-hop") || ($genre2 == "Pop" && $genre1 == "Hip-hop")) {
        echo $popHiphop;
    }
    else if (($genre1 == "Pop" && $genre2 == "Country") || ($genre2 == "Pop" && $genre1 == "Country")) {
        echo $popCountry;
    }
    else if (($genre1 == "Punk" && $genre2 == "Rock") || ($genre2 == "Punk" && $genre1 == "Rock")) {
        echo $punkRock;
    }
    else if (($genre1 == "Hip-hop" && $genre2 == "Rock") || ($genre2 == "Hip-hop" && $genre1 == "Rock")) {
        echo $rockHiphop;
    }
    else if (($genre1 == "Country" && $genre2 == "Rock") || ($genre2 == "Country" && $genre1 == "Rock")) {
        echo $rockCountry;
    }
    else if (($genre1 == "Punk" && $genre2 == "Hip-hop") || ($genre2 == "Punk" && $genre1 == "Hip-hop")) {
        echo $punkHiphop;
    }
    else if (($genre1 == "Punk" && $genre2 == "Country") || ($genre2 == "Punk" && $genre1 == "Country")) {
        echo $punkCountry;
    }
    else if (($genre1 == "Hip-hop" && $genre2 == "Country") || ($genre2 == "Hip-hop" && $genre1 == "Country")) {
        echo $countryHiphop;
    }
    ?>
    <article>
        <form action="viewFavArtists.php" method="post">
            <label for="favArtist">Enter your favorite artist in this genre:</label>
            <input type="text" id="favArtist" name="favArtist">
        </form>
    </article>
</body>
</html> 