<?php
$username = $_POST['username'];
$password = $_POST['password'];
$uname = htmlentities($username);
$pword = htmlentities($password);

$db = new mysqli("localhost", "HMT", "123", "Login");

$sql = "INSERT INTO Users (Username, Password)
VALUES ('$uname', '$pword')";

if (strlen($username) < 10 || strlen($username) > 30) {
    echo "Error: Invalid Username length";
} else if (strlen($password) < 6 || strlen($password) > 15) {
    echo "Error Invalid Username length";
  } else if (!$db) {
    die("Connection failed". mysqli_connect_error());
} else if (mysqli_query($db, $sql)) {
    echo "User Logged in";
}

  mysqli_close($db);
?>