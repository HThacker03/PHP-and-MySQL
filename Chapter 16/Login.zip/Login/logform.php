<?php
$username = $_POST['username'];
$password = $_POST['password'];

if (!$username || !$password) {
  echo '<p>You are missing a username or password</p>';
  exit;
}

$db = new mysqli("localhost", "HMT", "123", "Login");

if ($db-> connect_errno) {
  echo "Failed to connect to database: ". $db->connect_error;
  exit();
}



$sql = "SELECT Username FROM Users WHERE Username = '".$username."'";
$sql2 = "SELECT Password FROM Users WHERE Password = '".$password."'";

if (mysqli_query($db, $sql)->num_rows < 1) {
  echo "<h1>Wrong Username</h1>";
} else if (mysqli_query($db, $sql2)->num_rows < 1) {
  echo "<h1>Wrong Password</h1>";
} else {
  echo "<h1>Log in Successful</h1>";
}


  mysqli_close($db);
?>