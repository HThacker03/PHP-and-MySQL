<?php

//create short variable names
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$feedback = trim($_POST['feedback']);

//set up some static information
$toaddress = "thacker.han0353@stu.stech.edu";

// Change the $toaddress if the criteria are met
if (stristr($feedback, 'shop')) {
  $toaddress = 'retail@example.com';
} else if (stristr($feedback, 'delivery')) {
  $toaddress = 'fulfillment@example.com';
} else if (stristr($feedback, 'bill')) {
  $toaddress = 'accounts@example.com';
}

$subject = "Feedback from web site";

$mailcontent = "Customer name: ".str_replace("\r\n", "", $name)."\n".
               "Customer email: ".str_replace("\r\n", "",$email)."\n".
               "Customer comments:\n".str_replace("\r\n", "",$feedback)."\n";

$fromaddress = "From: webserver@example.com";

$email_array = explode('@', $email);
if (strtolower($email_array[1]) == "bigcustomer.com") {
  $toaddress = "bob@example.com";
} else {
  $toaddress = "thacker.han0353@stu.stech.edu";
}

//invoke mail() function to send mail
mail($toaddress, $subject, $mailcontent, $fromaddress);

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Bob's Auto Parts - Feedback Submitted</title>
  </head>
  <body>

    <h1>Feedback submitted</h1>
    <p>Your feedback (shown  below) has been sent.</p>
    <p><?php echo nl2br(htmlspecialchars($feedback)); ?> </p>
  </body>
</html>