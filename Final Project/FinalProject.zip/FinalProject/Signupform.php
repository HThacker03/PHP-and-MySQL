<?php
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$uname = htmlentities($username);
$pword = htmlentities($password);

if (!$username) {
  echo '<p>You are missing a username</p>';
  exit;
}
if (!$password) {
  echo '<p>You are missing a password</p>';
  exit;
}
if (!$email) {
  echo '<p>You are missing an email</p>';
  exit;
}

$db = new mysqli("localhost", "HMT", "123", "SignUp");

if ($db-> connect_errno) {
  echo "Failed to connect to database: ". $db->connect_error;
  exit();
}

$sql = "INSERT INTO Users (Username, Password, Email)
VALUES ('$uname', '$pword', '$email')";

if (strlen($username) < 8 || strlen($username) > 30) {
    echo "Error: Invalid Username length";
} else if (strlen($password) < 6 || strlen($password) > 15) {
    echo "Error Invalid Password length";
} else if (is_numeric($password)){
    echo "Error: Password must include letters and numbers";
} else if (!$db) {
    die("Connection failed". mysqli_connect_error());
} else if (mysqli_query($db, $sql)) {
    echo "<h1>Account created clik here to <a href='Login.html'>Login</a></h1>";
}

  mysqli_close($db);
?>