<?php
  require('header.php');
?>

<body>
    <h1>Genre search</h1>

    <form action="results.php" method="post">
    <p><strong>Choose a Genre</strong><br/>
    <select name="search">
    <option value="Hip-hop Country">Hip-hop Country</option>
    <option value="Pop Country">Pop Country</option>
    <option value="Pop Hip-hop">Pop Hip-hop</option>
    <option value="Pop Punk">Pop Punk</option>
    <option value="Pop Rock">Pop Rock</option>
    <option value="Punk Country">Punk Country</option>
    <option value="Punk Hip-hop">Punk Hip-hop</option>
    <option value="Punk Rock">Punk Rock</option>
    <option value="Rock Country">Rock Country</option>
    <option value="Rock Hip-hop">Rock Hip-hop</option>
    </select>
    </p>

    <p><input type="submit" name="submit" value="Search"></p>
    </form>
</body>
</html>