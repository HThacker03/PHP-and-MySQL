<?php
  require('header.php');
  require_once("file_exceptions.php");
?>
<body>
    <?php
  $artists=$_POST['favArtist'];
  $user=2;
  $genre=3;

  @$db = new mysqli('localhost', 'hmt','123','FavArtists');

  if (mysqli_connect_errno()) {
    echo "<p>Error: Could not connec to database.<br />
          Please try again later.</p>";
    exit();
  }

  $query = "INSERT INTO User_Fav_Artists VALUES (?, ?, ?)";
  $stmt = $db->prepare($query);
  $stmt->bind_param("dds", $user, $genre, $artists);
  $stmt->execute();

  if ($stmt->affected_rows > 0) {
    echo "<p>Artist inserted into the database.</p>";
  } else {
      echo "<p>An error has occurred.<br/>
            The item was not added.</p>";
  }

  $db->close();

    ?>
</body>
</html>