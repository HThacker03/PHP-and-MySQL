<?php
  require('header.php');
?>

<body>
    <h1>Genre Search Results</h1>
    <?php
    $search=$_POST['search'];

    switch ($search) {
        case 'Hip-hop Country':
        case 'Pop Country':
        case 'Pop Hip-hop':
        case 'Pop Punk':
        case 'Pop Rock':
        case 'Punk Country':
        case 'Punk Hip-hop':
        case 'Punk Rock':
        case 'Rock Country':
        case 'Rock Hip-hop':
        break;
    }

    $db = new mysqli('localhost','hmt','123','FavArtists');
    if (mysqli_connect_errno()) {
        echo '<p>Error: Could not connect to database.<br/>
        Please try again later.</p>';
        exit();
    }

    $query = "SELECT Artists
              FROM FavArtists.$search";
    $stmt = $db->prepare($query);
    $stmt->bind_param("s", $search);
    $stmt->execute();
    

    $db->close();
    ?>
</body>
</html>