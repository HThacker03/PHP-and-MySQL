<DOCTYPE html>
<html>
<head>
<!--
    Author: Hannah Thacker
    Date: 02/21/2025

    Filename: FavoriteArtist.html
   -->
    <title>Top Artists</title>
    <meta charset="utf-8" />
    <link href="TArtists.css" rel="stylesheet" />
</head>
<body>
    <header>
        <h1>Top Artists</h1>
       <nav>
            <ul>
                <li><a href="FavoriteArtist.php">Home</a></li>
                <li><a href="Fbpage.php">Feedback</a></li>
            </ul>
        </nav>
    </header>