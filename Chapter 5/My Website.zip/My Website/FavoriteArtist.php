<?php
  require('header.php');
?>
<article>
        <h1>Fusion Artists</h1>
    <?php 
    require('FavArtForm.php');
    ?>
<?php
  require('footer.php');
?>