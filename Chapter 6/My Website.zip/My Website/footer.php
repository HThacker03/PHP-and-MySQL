    <footer>
        <h2>Rock on!</h2>
    </footer>
</body>
</html>