<?php
  require('header.php');
?>
<body>
    <?php
    $document_root = $_SERVER['DOCUMENT_ROOT'];
    $favArtist = $_POST["favArtist"];

    $fp = fopen($document_root."/My Website/FavArtList.txt", 'ab');
    fwrite($fp, "\n".$favArtist);
    fclose($fp);

    $fp = fopen($document_root."/My Website/FavArtList.txt", 'rb');

    rewind($fp);

    while (!feof($fp)) {
        $list= fgets($fp);
        echo htmlspecialchars($list)."<br />";
    }
    fclose($fp);

    require('FavArtForm.php');
    ?>
</body>
</html>